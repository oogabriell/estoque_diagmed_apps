from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime, timedelta
import pyodbc

app = Flask(__name__)

# Configurar a conexão com o banco de dados SQL Server
conn = pyodbc.connect(
    'Driver={SQL Server};'
    'Server=138.219.91.72,38000;'
    'Database=C8KRDC_128994_RM_PD;'
    'UID=CLT128994gabriel.gomes;'
    'PWD=iptju40167HJDMT@?;'
)

# Criar um cursor para executar consultas SQL
cursor = conn.cursor()

# Rota para exibir os leads
@app.route('/')
def index():
   
    return render_template('index.html')

    # Rota para exibir os leads
@app.route('/painel', methods=['GET', 'POST'])
def dados_estoque():
         
    cursor.execute("""SELECT GERAL.C, GERAL.D, GERAL.U1, GERAL.U2, GERAL.U3, GERAL.SD, GERAL.M1, GERAL.M2, GERAL.M3, GERAL.MEDIA, GERAL.SUGESTAO, '', GERAL.INV1, GERAL.INV2, GERAL.PMEDIO, GERAL.MINIMO,
                        CASE WHEN (GERAL.SD >0  AND GERAL.SUGESTAO=0 ) THEN 'ALTO' ELSE 
                        CASE WHEN (GERAL.SD >0 AND (GERAL.SUGESTAO/GERAL.SD) > 2.5) THEN 'NORMAL' ELSE 
                        CASE WHEN (GERAL.SD >0 AND (GERAL.SUGESTAO/GERAL.SD) > 2) THEN 'NORMAL' ELSE 
                        CASE WHEN (GERAL.SD = 0 AND GERAL.SUGESTAO>0 ) THEN 'BAIXO' ELSE
                        CASE WHEN (GERAL.SD > 0 AND GERAL.SUGESTAO>0) THEN 'BAIXO' ELSE
                        CASE WHEN (GERAL.SD = 0 AND GERAL.SUGESTAO=0 ) THEN
                             CASE WHEN GERAL.MINIMO > 0 THEN 'ABAIXO DO MINIMO' ELSE 'ZERADO' END ELSE
                        'NAO DEFINIDO' END END END END END END 
                        FROM 
                        (
                        SELECT U.CODIGO C, P.DESCRICAO D, UND.CODUNDCONTROLE U1, UND.CODUNDCOMPRA U2,UND.CODUNDVENDA U3, SUM(U.SALDO) SD, SUM(U.M1) M1, SUM(U.M2) M2, SUM(U.M3) M3, 
                               (SUM(U.M1)+SUM(U.M2)+SUM(U.M3))/3 MEDIA, 
                        CASE WHEN SUM(U.SALDO) > ((SUM(U.M1)+SUM(U.M2)+SUM(U.M3))/3) THEN 0  ELSE
                            ((SUM(U.M1)+SUM(U.M2)+SUM(U.M3))/3) - SUM(U.SALDO) END SUGESTAO,
                            SUM(U.INV_E) INV1, SUM(U.INV_S) INV2, P.CUSTOMEDIO PMEDIO, SUM(U.MINIMO) MINIMO
                           

                        FROM TPRD P LEFT JOIN TPRODUTODEF UND ON P.CODCOLIGADA = UND.CODCOLIGADA AND P.IDPRD = UND.IDPRD,
                        (
                         select P.CODIGOPRD CODIGO, ISNULL(L.SALDOFISICO2,0) SALDO, 0 M1, 0 M2, 0 M3 ,0 INV_E, 0 INV_S, 0 MINIMO
                         from tprd P 
                              LEFT JOIN TPRDLOC L ON P.CODCOLIGADA=L.CODCOLIGADA AND P.IDPRD = L.IDPRD
                                   AND P.CODCOLIGADA=1 AND L.CODFILIAL=1 
                                   AND SUBSTRING(P.CODIGOPRD,1,2)<>'02'
                                   
                        UNION ALL
                         select P.CODIGOPRD CODIGO, 0 SALDO, 0 M1, 0 M2, 0 M3 ,0 INV_E, 0 INV_S, ISNULL(L.SALDFISMIN,0) MINIMO
                         from TPRD P 
                              LEFT JOIN TPRDLOCINFO L ON P.CODCOLIGADA=L.CODCOLIGADA AND P.IDPRD = L.IDPRD
                                   AND P.CODCOLIGADA=1 AND L.CODFILIAL=1 
                                   AND SUBSTRING(P.CODIGOPRD,1,2)<>'02'

                        UNION ALL
                        SELECT P.CODIGOPRD CODIGO, 0 SALDO, SUM(I.QUANTIDADE) M1, 0 M2, 0  M3,0 INV_E, 0 INV_S, 0 MINIMO
                        from tprd P, TMOV T, TITMMOV I
                        WHERE T.CODCOLIGADA=I.CODCOLIGADA AND T.IDMOV=I.IDMOV
                        AND I.CODCOLIGADA=P.CODCOLIGADA AND I.IDPRD=P.IDPRD
                        AND T.CODCOLIGADA=1 AND T.CODFILIAL=1
                        AND T.CODTMV='1.1.51' AND right(convert(varchar(10),T.DATAEMISSAO,103),7) = right(convert(varchar(10),getdate()-90,103),7)
                        GROUP BY P.CODIGOPRD
                          
                        UNION ALL
                        SELECT P.CODIGOPRD CODIGO, 0 SALDO, 0 M1,SUM(I.QUANTIDADE) M2, 0 M3,0 INV_E, 0 INV_S, 0 MINIMO
                        from tprd P, TMOV T, TITMMOV I
                        WHERE T.CODCOLIGADA=I.CODCOLIGADA AND T.IDMOV=I.IDMOV
                        AND I.CODCOLIGADA=P.CODCOLIGADA AND I.IDPRD=P.IDPRD
                        AND T.CODCOLIGADA=1 AND T.CODFILIAL=1
                        AND T.CODTMV='1.1.51' AND right(CONVERT(VARCHAR(10),T.DATAEMISSAO,103),7)= right(convert(varchar(10),getdate()-59,103),7)
                        GROUP BY P.CODIGOPRD
                          
                        UNION ALL
                        SELECT P.CODIGOPRD CODIGO, 0 SALDO, 0 M1, 0 M2, SUM(I.QUANTIDADE) M3,0 INV_E, 0 INV_S, 0 MINIMO
                        from tprd P, TMOV T, TITMMOV I
                        WHERE T.CODCOLIGADA=I.CODCOLIGADA AND T.IDMOV=I.IDMOV
                        AND I.CODCOLIGADA=P.CODCOLIGADA AND I.IDPRD=P.IDPRD
                        AND T.CODCOLIGADA=1 AND T.CODFILIAL=1
                        AND T.CODTMV='1.1.51' AND right(CONVERT(VARCHAR(10),T.DATAEMISSAO,103),7)= right(convert(varchar(10),getdate()-30,103),7)
                        GROUP BY P.CODIGOPRD
                          
                        UNION ALL
                        SELECT P.CODIGOPRD CODIGO, 0 SALDO, 0 M1, 0 M2,0 M3,SUM(I.QUANTIDADE) INV_E, 0 INV_S, 0 MINIMO
                        from tprd P, TMOV T, TITMMOV I
                        WHERE T.CODCOLIGADA=I.CODCOLIGADA AND T.IDMOV=I.IDMOV
                        AND I.CODCOLIGADA=P.CODCOLIGADA AND I.IDPRD=P.IDPRD
                        AND T.CODCOLIGADA=1 AND T.CODFILIAL=1
                        AND T.CODTMV='4.1.01' AND right(CONVERT(VARCHAR(10),T.DATAEMISSAO,103),7)= right(convert(varchar(10),getdate()-30,103),7)
                        GROUP BY P.CODIGOPRD
                          
                        UNION ALL
                        SELECT P.CODIGOPRD CODIGO, 0 SALDO, 0 M1, 0 M2, 0 M3, 0 INV_E, SUM(I.QUANTIDADE) INV_S, 0 MINIMO
                        from tprd P, TMOV T, TITMMOV I
                        WHERE T.CODCOLIGADA=I.CODCOLIGADA AND T.IDMOV=I.IDMOV
                        AND I.CODCOLIGADA=P.CODCOLIGADA AND I.IDPRD=P.IDPRD
                        AND T.CODCOLIGADA=1 AND T.CODFILIAL=1
                        AND T.CODTMV='4.1.03' AND right(CONVERT(VARCHAR(10),T.DATAEMISSAO,103),7)= right(convert(varchar(10),getdate()-30,103),7)
                        GROUP BY P.CODIGOPRD
                        ) U
                        WHERE P.CODCOLIGADA =1 AND P.CODIGOPRD=U.CODIGO
                        AND P.ULTIMONIVEL=1 AND SUBSTRING(P.CODIGOPRD,1,2)<>'02'
                        AND P.INATIVO=0 
                        GROUP BY U.CODIGO, P.DESCRICAO,P.CUSTOMEDIO,UND.CODUNDCONTROLE, UND.CODUNDCOMPRA, UND.CODUNDVENDA
                        ) GERAL

                        ORDER BY GERAL.C """)
    
    
    dados = cursor.fetchall()

    

    

    return render_template('painel.html', dados=dados)

if __name__ == '__main__':
    app.run(debug=True)
